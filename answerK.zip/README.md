# term_project

### AnswerK
  AnswerK is an application that users can test him/herselves in some topics like sport, culture and programming. First of all, you need to have an username with a password to login. These datas are stored in a txt file. After successfull login, you will be directed to main menu. In this menu, you can choose whatever you want like apply quiz, see rank table, plot the graph of your stats and review settings. In settings, user can change password or remove account. To quit account you need to press 'q'. You can also use 'q' to finish program. There will be 7 questions for each quiz. Questions are choosen randomly from question pool and each right answers will be graded as 10. 
  All you need to do is to follow directions and select what you want to do.
